# Comentarios de la entrega 1 (Entrega de la propuesta)

Falta mejorar un poco la descripción. Explicar cada elemento de la lista de las EN. 

Falta indicar quien es el coordinador.

Faltan crear las ramas.

Falta crear las tareas (issues) del proyecto. Como ya sabéis las funcionalidades tanto de la parte pública como la parte privada, tenéis que incorporar las tareas y asignarlas a cada componente del equipo. También podéis crear el resto de milestones.
