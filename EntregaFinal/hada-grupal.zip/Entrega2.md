# Comentarios de la entrega 2 (Entrega de EN/CAD y esquema de la BD)

- Faltaría detallar más la definición de las tareas. Tenéis que definir las tareas con antelación a las entregas, y modificar el estado(to, in progress, etc) de cada una de ellas en la pizarra del proyecto. Si accedeis a Projects y seleccionáis el proyecto, podéis ver y gestionar la pizarra del proyecto. Hay un botón que es Add cards, para añadir los issues definidos.

- En el esquema , no acabo de entender el concepto de coche en vuestro sistema, porque supuestamente os dedicaís a la compra/alquiler de propiedades inmobiliarias.

- La entrega es correcta.
