﻿namespace library
{
    public class ENAnuncio
    {
        public uint id = 0; //clave primaria
        private string _titulo, _localidad, _descripcion;
        private float _precio;
        private int _cp;
        private bool coche = false; //if true creamos coche, else crear propiedad

        public string titulo
        {
            get { return _titulo; }
            set { _titulo = value; }
        }
        public string localidad
        {
            get { return _localidad; }
            set { _localidad = value; }
        }
        public string descripcion
        {
            get { return _descripcion; }
            set { _descripcion = value; }
        }
        public float precio
        {
            get { return _precio; }
            set { _precio = value; }
        }
        public int cp
        {
            get { return _cp; }
            set { _cp = value; }
        }

        public ENAnuncio()
        {
            titulo = "";
            localidad = "";
            descripcion = "";
            precio = -1;
            cp = -1;
        }
        public ENAnuncio(string title, string city, string description, float price, int codPostal)
        {
            titulo = title;
            localidad = city;
            descripcion = description;
            precio = price;
            cp = codPostal;
        }

        public bool createAnuncio()
        {
            CADAnuncio anuncio = new CADAnuncio();
            bool creado = false;
            if (coche)
            {
                ENCoche coche = new ENCoche();
                if (coche.createCoche(id))
                    if (anuncio.createAnuncio(this, id))
                    {
                        creado = true;
                        id++;
                    }
            }
            else
            {
                ENPropiedad prop = new ENPropiedad();
                if (prop.createPropiedad(id))
                    if (anuncio.createAnuncio(this, id))
                    {
                        creado = true;
                        id++;
                    }
            }
            return creado;
        }

        public bool deleteAnuncio()
        {
            CADAnuncio anuncio = new CADAnuncio();
            bool deleted = false;
            if (anuncio.deleteAnuncio(this, id))
                deleted = true;
            return deleted;
        }
        public bool updateAnuncio()
        {
            CADAnuncio anuncio = new CADAnuncio();
            bool updated = false;
            if (anuncio.updateAnuncio(this, id))
                updated = true;

            return updated;
        }
        public bool readAnuncio()
        {
            CADAnuncio anuncio = new CADAnuncio();
            bool deleted = false;
            if (anuncio.readAnuncio(this, id))
                deleted = true;

            return deleted;
        }
        public bool readNextAnuncio()
        {
            CADAnuncio anuncio = new CADAnuncio();
            bool read = false;
            if (anuncio.readNextAnuncio(this, id))
                read = true;

            return read;
        }
        public bool readFirstAnuncio()
        {
            CADAnuncio anuncio = new CADAnuncio();
            bool read = false;
            if (anuncio.readFirstAnuncio(this, id))
                read = true;

            return read;
        }
    }
}
