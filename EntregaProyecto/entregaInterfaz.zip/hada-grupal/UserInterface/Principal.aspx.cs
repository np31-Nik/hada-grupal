﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UserInterface
{
    public partial class Principal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Oferta1(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta2(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta3(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta4(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta5(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta6(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta7(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta8(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta9(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
        protected void Oferta10(object sender, EventArgs e)
        {
            Response.Redirect("~/Anuncio.aspx");

        }
    }
}