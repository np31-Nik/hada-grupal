﻿using System;

namespace library
{
    public class CADBanco
    {
        private String conexstring;

        public CADBanco()
        {

        }

        public bool createBanco(ENBanco en)
        {
            bool creado = false;
            return creado;
        }

        public bool deleteBanco(ENBanco en)
        {
            bool eliminado = false;
            return eliminado;
        }

        public bool readBanco(ENBanco en)
        {
            bool leido = false;
            return leido;
        }

        public bool readFirstBanco(ENBanco en)
        {
            bool leido = false;
            return leido;
        }

        public bool readNextBanco(ENBanco en)
        {
            bool leido = false;
            return leido;
        }

        public bool readPrevBanco(ENBanco en)
        {
            bool leido = false;
            return leido;
        }

        public bool updateBanco(ENBanco en)
        {
            bool act = false;
            return act;
        }
    }
}
